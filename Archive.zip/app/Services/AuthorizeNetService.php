<?php

namespace App\Services;

use App\Models\User;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use net\authorize\api\contract\v1 as AnetAPI;
use net\authorize\api\controller as AnetController;
use Exception;

class AuthorizeNetService
{
    protected $merchantAuthentication;

    public function __construct()
    {
        $this->merchantAuthentication = new AnetAPI\MerchantAuthenticationType();

        // Use environment variables for Authorize.Net credentials
        $this->merchantAuthentication->setName(env('ANET_LOGIN_ID'));
        $this->merchantAuthentication->setTransactionKey(env('ANET_TRANSACTION_KEY'));
    }

    /**
     * Get the Authorize.Net environment based on .env configuration
     */
    protected function getApiEnvironment()
    {
        return env('ANET_ENV', 'sandbox') === 'production'
            ? \net\authorize\api\constants\ANetEnvironment::PRODUCTION
            : \net\authorize\api\constants\ANetEnvironment::SANDBOX;
    }

    function getCustomerPaymentProfile(
        string $customerProfileId,
        string $customerPaymentProfileId
    ) {

        // Set the transaction's refId
        $refId = 'ref' . time();

        //request requires customerProfileId and customerPaymentProfileId
        $request = new AnetAPI\GetCustomerPaymentProfileRequest();
        $request->setMerchantAuthentication($this->merchantAuthentication);
        $request->setRefId($refId);
        $request->setCustomerProfileId($customerProfileId);
        $request->setCustomerPaymentProfileId($customerPaymentProfileId);

        $controller = new AnetController\GetCustomerPaymentProfileController($request);
        $response = $controller->executeWithApiResponse($this->getApiEnvironment());

        if (($response != null)) {
            if ($response->getMessages()->getResultCode() == "Ok") {
                try {
                    // Try to access payment profile - method names may vary in different API versions
                    $paymentProfile = method_exists($response, 'getPaymentProfile')
                        ? $response->getPaymentProfile()
                        : $response->getProfile();

                    if ($paymentProfile) {
                        $payment = $paymentProfile->getPayment();
                        $billTo = method_exists($paymentProfile, 'getBillTo')
                            ? $paymentProfile->getBillTo()
                            : $paymentProfile->getbillTo();

                        return [
                            "last4" => $payment->getCreditCard()->getCardNumber(),
                            "billing_address" => $billTo->getAddress()
                        ];
                    } else {
                        return ['error' => 'Unable to retrieve payment profile'];
                    }
                } catch (\Exception $e) {
                    return ['error' => 'Error parsing payment profile: ' . $e->getMessage()];
                }
            } else {
                $errorMessages = $response->getMessages()->getMessage();
                return [
                    'error' => "Response : " . $errorMessages[0]->getCode() . "  " . $errorMessages[0]->getText() . "\n"
                ];
            }
        } else {
            return [
                'error' => "NULL Response Error"
            ];
        }
    }

    // Create Customer Profile
    public function createCustomerProfile(
        User $user,
        string $cardNumber,
        string $expirationDate,
        string $ccv,
        string $firstName,
        string $lastName,
        string $company,
        string $address,
        string $city,
        string $state,
        string $zip,
        string $country
    ): array {
        try {
            // Set the transaction's refId
            $refId = 'ref' . time();

            // Set credit card information for payment profile
            $creditCard = new AnetAPI\CreditCardType();
            $creditCard->setCardNumber($cardNumber);
            $creditCard->setExpirationDate($expirationDate);
            $creditCard->setCardCode($ccv);
            $paymentCreditCard = new AnetAPI\PaymentType();
            $paymentCreditCard->setCreditCard($creditCard);

            // Create the Bill To info for new payment type
            $billTo = new AnetAPI\CustomerAddressType();
            $billTo->setFirstName($firstName);
            $billTo->setLastName($lastName);
            $billTo->setCompany($company);
            $billTo->setAddress($address);
            $billTo->setCity($city);
            $billTo->setState($state);
            $billTo->setZip($zip);
            $billTo->setCountry($country);
            $billTo->setPhoneNumber($user->phone);

            // Create a customer shipping address
            $customerShippingAddress = new AnetAPI\CustomerAddressType();
            $customerShippingAddress->setFirstName($firstName);
            $customerShippingAddress->setLastName($lastName);
            $customerShippingAddress->setCompany($company);
            $customerShippingAddress->setAddress($address);
            $customerShippingAddress->setCity($city);
            $customerShippingAddress->setState($state);
            $customerShippingAddress->setZip($zip);
            $customerShippingAddress->setCountry($country);
            $customerShippingAddress->setPhoneNumber($user->phone);

            // Create an array of any shipping addresses
            $shippingProfiles[] = $customerShippingAddress;

            // Create a new CustomerPaymentProfile object
            $paymentProfile = new AnetAPI\CustomerPaymentProfileType();
            $paymentProfile->setCustomerType('individual');
            $paymentProfile->setBillTo($billTo);
            $paymentProfile->setPayment($paymentCreditCard);
            $paymentProfiles[] = $paymentProfile;

            // Create a new CustomerProfileType and add the payment profile object
            $customerProfile = new AnetAPI\CustomerProfileType();
            $customerProfile->setDescription("$user->name Subscription Payment");
            $customerProfile->setMerchantCustomerId("M_" . time());
            $customerProfile->setEmail($user->email);
            $customerProfile->setpaymentProfiles($paymentProfiles);
            $customerProfile->setShipToList($shippingProfiles);

            // Assemble the complete transaction request
            $request = new AnetAPI\CreateCustomerProfileRequest();
            $request->setMerchantAuthentication($this->merchantAuthentication);
            $request->setRefId($refId);
            $request->setProfile($customerProfile);

            // Create the controller and get the response
            $controller = new AnetController\CreateCustomerProfileController($request);
            $response = $controller->executeWithApiResponse($this->getApiEnvironment());

            if (($response != null) && ($response->getMessages()->getResultCode() == "Ok")) {
                $paymentProfiles = $response->getCustomerPaymentProfileIdList();

                return [
                    'customer_profile_id' => $response->getCustomerProfileId(),
                    'payment_profile_id' => (string) $paymentProfiles[0]
                ];

            } else {
                $errorMessages = $response->getMessages()->getMessage();
                return ['error' => "Response : " . $errorMessages[0]->getCode() . "  " . $errorMessages[0]->getText() . "\n"];
            }
        } catch (\Throwable $th) {
            return ['error' => $th->getMessage() . $th->getLine() . ' ' . $th->getFile()];
        }
    }

    public function updateCustomerProfile(
        string $customerProfileId,
        string $customerPaymentProfileId,
        User $user,
        string $cardNumber,
        string $expirationDate,
        string $ccv,
        string $firstName,
        string $lastName,
        string $company,
        string $address,
        string $city,
        string $state,
        string $zip,
        string $country
    ) {
        try {
            // Set the transaction's refId
            $refId = 'ref' . time();

            $request = new AnetAPI\GetCustomerPaymentProfileRequest();
            $request->setMerchantAuthentication($this->merchantAuthentication);
            $request->setRefId($refId);
            $request->setCustomerProfileId($customerProfileId);
            $request->setCustomerPaymentProfileId($customerPaymentProfileId);

            $controller = new AnetController\GetCustomerPaymentProfileController($request);
            $response = $controller->executeWithApiResponse($this->getApiEnvironment());
            if (($response != null) && ($response->getMessages()->getResultCode() == "Ok")) {
                $billto = new AnetAPI\CustomerAddressType();
                $billto = $response->getPaymentProfile()->getBillTo();

                $creditCard = new AnetAPI\CreditCardType();
                $creditCard->setCardNumber($cardNumber);
                $creditCard->setExpirationDate($expirationDate);
                $creditCard->setCardCode($ccv);

                $paymentCreditCard = new AnetAPI\PaymentType();
                $paymentCreditCard->setCreditCard($creditCard);
                $paymentprofile = new AnetAPI\CustomerPaymentProfileExType();
                $paymentprofile->setBillTo($billto);
                $paymentprofile->setCustomerPaymentProfileId($customerPaymentProfileId);
                $paymentprofile->setPayment($paymentCreditCard);

                // Update the Bill To info for new payment type
                $billTo = new AnetAPI\CustomerAddressType();
                $billTo->setFirstName($firstName);
                $billTo->setLastName($lastName);
                $billTo->setCompany($company);
                $billTo->setAddress($address);
                $billTo->setCity($city);
                $billTo->setState($state);
                $billTo->setZip($zip);
                $billTo->setCountry($country);
                $billTo->setPhoneNumber($user->phone);

                // Update the Customer Payment Profile object
                $paymentprofile->setBillTo($billto);

                // Submit a UpdatePaymentProfileRequest
                $request = new AnetAPI\UpdateCustomerPaymentProfileRequest();
                $request->setMerchantAuthentication($this->merchantAuthentication);
                $request->setCustomerProfileId($customerProfileId);
                $request->setPaymentProfile($paymentprofile);

                $controller = new AnetController\UpdateCustomerPaymentProfileController($request);
                $response = $controller->executeWithApiResponse($this->getApiEnvironment());
                if (($response != null) && ($response->getMessages()->getResultCode() == "Ok")) {
                    return [
                        'customer_profile_id' => $customerProfileId,
                        'payment_profile_id' => $paymentprofile->getCustomerPaymentProfileId()
                    ];
                } else if ($response != null) {
                    $errorMessages = $response->getMessages()->getMessage();
                    return ['error' => "Update Customer Payment Profile ERROR: " . $errorMessages[0]->getCode() . "  " . $errorMessages[0]->getText() . "\n"];
                }
            } else {
                $errorMessages = $response->getMessages()->getMessage();
                return ['error' => "Update Customer Payment Profile ERROR: " . $errorMessages[0]->getCode() . "  " . $errorMessages[0]->getText() . "\n"];
            }
        } catch (\Throwable $th) {
            return ['error' => $th->getMessage() . $th->getLine() . ' ' . $th->getFile()];
        }
    }

    public function addressFromCoordinate($latitude, $longitude)
    {
        $apiKey = "AIzaSyBmaS0B0qwokES4a_CiFNVkVJGkimXkNsk";
        $url = "https://maps.googleapis.com/maps/api/geocode/json";

        $response = Http::get($url, [
            'latlng' => "$latitude,$longitude",
            'key' => $apiKey
        ]);

        if ($response->successful()) {
            $results = $response->json()['results'][0]['address_components'] ?? [];

            $components = [
                'city' => '',
                'state' => '',
                'country' => '',
                'zipcode' => ''
            ];

            foreach ($results as $component) {
                $types = $component['types'];

                if (in_array('locality', $types)) {
                    $components['city'] = $component['long_name'];
                }

                if (in_array('administrative_area_level_1', $types)) {
                    $components['state'] = $component['long_name'];
                }

                if (in_array('country', $types)) {
                    $components['country'] = $component['long_name'];
                }

                if (in_array('postal_code', $types)) {
                    $components['zipcode'] = $component['long_name'];
                }
            }

            return $components;
        }

        return null;
    }

    // Process one-time payment using payment profile
    public function processPayment(string $customerProfileId, string $paymentProfileId, float $amount): array
    {
        // Set the transaction's refId
        $refId = 'ref' . time();

        $profileToCharge = new AnetAPI\CustomerProfilePaymentType();
        $profileToCharge->setCustomerProfileId($customerProfileId);
        $paymentProfile = new AnetAPI\PaymentProfileType();
        $paymentProfile->setPaymentProfileId($paymentProfileId);
        $profileToCharge->setPaymentProfile($paymentProfile);

        $transactionRequestType = new AnetAPI\TransactionRequestType();
        $transactionRequestType->setTransactionType("authCaptureTransaction");
        $transactionRequestType->setAmount($amount);
        $transactionRequestType->setProfile($profileToCharge);

        $request = new AnetAPI\CreateTransactionRequest();
        $request->setMerchantAuthentication($this->merchantAuthentication);
        $request->setRefId($refId);
        $request->setTransactionRequest($transactionRequestType);
        $controller = new AnetController\CreateTransactionController($request);
        $response = $controller->executeWithApiResponse($this->getApiEnvironment());

        if ($response && $response->getMessages()->getResultCode() === "Ok") {
            $transactionResponse = $response->getTransactionResponse();
            if ($transactionResponse && $transactionResponse->getResponseCode() == '1') {
                return ['success' => true, 'transaction_id' => $transactionResponse->getTransId()];
            }
            $errors = $transactionResponse->getErrors();
            return ['error' => $errors ? $errors[0]->getErrorText() : 'Transaction Failed'];
        } else {
            return ['error' => $this->getErrorMessages($response)];
        }
    }

    // Create Recurring Subscription for Business Users
    public function createRecurringSubscription(
        string $customerProfileId,
        string $paymentProfileId,
        float $amount,
        string $subscriptionName,
        string $billingCycle = 'monthly',
        \DateTime $startDate = null,
        int $totalOccurrences = 9999
    ): array {
        try {
            // Set the transaction's refId
            $refId = 'ref' . time();

            $subscription = new AnetAPI\ARBSubscriptionType();
            $subscription->setName($subscriptionName);

            // Set billing interval based on billing cycle
            $interval = new AnetAPI\PaymentScheduleType\IntervalAType();
            switch (strtolower($billingCycle)) {
                case 'daily':
                    // Authorize.Net requires minimum 7 days for day-based subscriptions
                    // So we'll use weekly (7 days) for daily billing cycles
                    $interval->setLength(7);
                    $interval->setUnit('days');
                    break;
                case 'weekly':
                    $interval->setLength(7);
                    $interval->setUnit('days');
                    break;
                case 'monthly':
                    $interval->setLength(1);
                    $interval->setUnit('months');
                    break;
                case 'annually':
                case 'yearly':
                    $interval->setLength(12);
                    $interval->setUnit('months');
                    break;
                case 'one-time':
                    $interval->setLength(1);
                    $interval->setUnit('months');
                    break;
                default:
                    // Default to monthly if unknown billing cycle
                    $interval->setLength(1);
                    $interval->setUnit('months');
                    break;
            }

            $paymentSchedule = new AnetAPI\PaymentScheduleType();
            $paymentSchedule->setInterval($interval);
            $paymentSchedule->setStartDate($startDate ?: new \DateTime());
            $paymentSchedule->setTotalOccurrences($totalOccurrences);

            $subscription->setPaymentSchedule($paymentSchedule);
            $subscription->setAmount($amount);

            // Set customer profile
            $profile = new AnetAPI\CustomerProfileIdType();
            $profile->setCustomerProfileId($customerProfileId);
            $profile->setCustomerPaymentProfileId($paymentProfileId);
            $subscription->setProfile($profile);

            // Create the request
            $request = new AnetAPI\ARBCreateSubscriptionRequest();
            $request->setMerchantAuthentication($this->merchantAuthentication);
            $request->setRefId($refId);
            $request->setSubscription($subscription);

            $controller = new AnetController\ARBCreateSubscriptionController($request);
            $response = $controller->executeWithApiResponse($this->getApiEnvironment());

            if ($response && $response->getMessages()->getResultCode() === "Ok") {
                return [
                    'success' => true,
                    'subscription_id' => $response->getSubscriptionId(),
                    'message' => 'Recurring subscription created successfully'
                ];
            } else {
                return [
                    'success' => false,
                    'error' => $this->getErrorMessages($response)
                ];
            }
        } catch (\Throwable $th) {
            return [
                'success' => false,
                'error' => $th->getMessage() . ' at line ' . $th->getLine() . ' in ' . $th->getFile()
            ];
        }
    }

    // Cancel Recurring Subscription
    public function cancelRecurringSubscription(string $subscriptionId): array
    {
        try {
            $refId = 'ref' . time();

            $request = new AnetAPI\ARBCancelSubscriptionRequest();
            $request->setMerchantAuthentication($this->merchantAuthentication);
            $request->setRefId($refId);
            $request->setSubscriptionId($subscriptionId);

            $controller = new AnetController\ARBCancelSubscriptionController($request);
            $response = $controller->executeWithApiResponse($this->getApiEnvironment());

            if ($response && $response->getMessages()->getResultCode() === "Ok") {
                return [
                    'success' => true,
                    'message' => 'Subscription cancelled successfully'
                ];
            } else {
                return [
                    'success' => false,
                    'error' => $this->getErrorMessages($response)
                ];
            }
        } catch (\Throwable $th) {
            return [
                'success' => false,
                'error' => $th->getMessage() . ' at line ' . $th->getLine() . ' in ' . $th->getFile()
            ];
        }
    }

    // Get Subscription Status
    public function getSubscriptionStatus(string $subscriptionId): array
    {
        try {
            $refId = 'ref' . time();

            $request = new AnetAPI\ARBGetSubscriptionStatusRequest();
            $request->setMerchantAuthentication($this->merchantAuthentication);
            $request->setRefId($refId);
            $request->setSubscriptionId($subscriptionId);

            $controller = new AnetController\ARBGetSubscriptionStatusController($request);
            $response = $controller->executeWithApiResponse($this->getApiEnvironment());

            if ($response && $response->getMessages()->getResultCode() === "Ok") {
                return [
                    'success' => true,
                    'status' => $response->getStatus(),
                    'message' => 'Subscription status retrieved successfully'
                ];
            } else {
                return [
                    'success' => false,
                    'error' => $this->getErrorMessages($response)
                ];
            }
        } catch (\Throwable $th) {
            return [
                'success' => false,
                'error' => $th->getMessage() . ' at line ' . $th->getLine() . ' in ' . $th->getFile()
            ];
        }
    }

    // Update Recurring Subscription
    public function updateRecurringSubscription(string $subscriptionId, float $amount): array
    {
        try {
            $refId = 'ref' . time();

            $subscription = new AnetAPI\ARBSubscriptionType();
            $subscription->setAmount($amount);

            $request = new AnetAPI\ARBUpdateSubscriptionRequest();
            $request->setMerchantAuthentication($this->merchantAuthentication);
            $request->setRefId($refId);
            $request->setSubscriptionId($subscriptionId);
            $request->setSubscription($subscription);

            $controller = new AnetController\ARBUpdateSubscriptionController($request);
            $response = $controller->executeWithApiResponse($this->getApiEnvironment());

            if ($response && $response->getMessages()->getResultCode() === "Ok") {
                return [
                    'success' => true,
                    'message' => 'Subscription updated successfully'
                ];
            } else {
                return [
                    'success' => false,
                    'error' => $this->getErrorMessages($response)
                ];
            }
        } catch (\Throwable $th) {
            return [
                'success' => false,
                'error' => $th->getMessage() . ' at line ' . $th->getLine() . ' in ' . $th->getFile()
            ];
        }
    }

    // Utility to extract error messages from response
    protected function getErrorMessages($response): string
    {
        if (!$response) {
            return 'No response from Authorize.Net API.';
        }
        if ($response->getMessages()) {
            $messages = $response->getMessages()->getMessage();
            if (count($messages)) {
                return $messages[0]->getText();
            }
        }
        return 'Unknown error';
    }
}
